//add by yixt 2008-06-05 �ı�����ʾ������ʾ
function EM(id)
{
	return $("#" + id);//��EM()��������document.getElementById(id)
}
function divNoShow()
{
	EM("ShowTipDisp").style.display='none';
	EM("FramTipDisp").style.display='none';
}
function ShowTips(objInputName, objCodeName, DDName)//����array
{
	var objInput = EM(objInputName); //�ı������
	var objCode = EM(objCodeName); //�ı������
	var vCoid = "";
    var initflag;
	var selectedIndex=-1;
    if (objInput==null) 
    {
    	alert('������ʼ��ʧ��:û���ҵ�"'+objInputName+'"�ı���');
    	return ;
    }
    //�ı���ʧȥ����
    objInput.onblur=divNoShow;
    
    //�ı��򰴼�̧��
    objInput.onkeyup=checkKeyCode;
    
    //�ı����������ַ����仯
    initflag = 0;
    objInput.onpropertychange=checkAndShow;
    //�ı���õ�����
    initflag = 0;
    objInput.onfocus=checkAndShow;
    
    
	//������ʾ���»س�
    function checkKeyCode()
    {
		selectedIndex=checkKey(objInput,selectedIndex,DDName);
    }
    
	//������ʾѡ�����ʾ
    function checkAndShow(evt)
    {
		if(initflag == 0)
		{
			initflag = 1;
			return;
		}
		selectedIndex=-1;
		var DivOptions = "";
    	divClean();
		
		var arr_v=getArrByType(DDName,'v');
		var arr_c=getArrByType(DDName,'c');
		var arr_e=getArrByType(DDName,'e');
		
		if(DDName=='division' || DDName=='company')	
		{
			var arr_m=getArrByType(DDName,'m');
		}
		if(DDName=='division')
			var arr_p=getArrByType(DDName,'p');
			
		if(DDName=='funtype' || DDName=='funtypecat')
			var strInput = JTrim(objInput.value);
		else
        	var strInput = JStrim(objInput.value);
        
        if(strInput=="")
		{
			if(DDName=='division')
			{
				for (var i=0;i<arr_v.length;i++) 
				{
					if(arr_p[i]==vCoID)
						DivOptions += GetOption(objInputName,arr_c[i],arr_e[i]);
				}
			}
			else
			{
				if(DDName!='jobarea' && DDName!='jobareaold')
				{
					DivOptions = getAllOption(objInputName,arr_v,arr_c,arr_e);
				}
	    }
    }
        else
        {
        	if(DDName=='division')
			{
				for (var i=0;i<arr_v.length;i++)
	            {
	            	if(arr_p[i]==vCoID)
	            	{
		        		if(IfPosStr(strInput,arr_c[i],arr_e[i]))
		            	{
		                    DivOptions += GetOption(objInputName,arr_c[i],arr_e[i]);
		                }
		            }
				}
			}
			else
			{
	            for (var i=0;i<arr_v.length;i++)
	            {
	        		if(IfPosStr(strInput,arr_c[i],arr_e[i]))
	            	{
	                    DivOptions += GetOption(objInputName,arr_c[i],arr_e[i]);
	                }
				}
			}
		}
    	objCode.value = GetCodeByStr(strInput,arr_v,arr_c);
    	divShow(DivOptions,objInput);
    }
}
