(function() {
	if ( window.NewMajorLayer ) {
		alert( 'variable NewMajorLayer has been used,it will be replaced with _NewMajorLayer!' );
		window._NewMajorLayer = window.NewMajorLayer;
	}

	//constructor
	window.NewMajorLayer = function( param ) {
		
		param = param instanceof Object ? param : {};
		param.cfg = cfg;
		param.colNum = param.colNum || 5;
		param.data = ma;
		param.isMulty = false;
		param.isHasNolimit = false;
		param.headTitle = param.cfg.langs.zyfl;
		param.selectedTitle = param.cfg.langs.zhuanye;
		param.initTblFunc = this.initNewMajorLayer;
		param.getSubColNum = this.getNewMajorLayerSubColNum;
		JobLayer.apply( this , [param] );
	}.$extends( JobLayer );

	//share property & method
	var pt = NewMajorLayer.prototype;
	
	//רҵ���������ֵ�
	pt.NewMajorLayerPare = [
		{ Chinese : '��ѧ' , English : 'Philosophy' , subIds : [ '1100' ] } ,
		{ Chinese : '����ѧ' , English : 'Economics' , subIds : [ '1000' ] } ,
		{ Chinese : '����ѧ' , English : 'Management' , subIds : [ '0200' , '0300' , '0400' , '3500' ] } ,
		{ Chinese : '��ѧ' , English : 'Literature' , subIds : [ '0700' , '3900' , '1200' ] } ,
		{ Chinese : '��ѧ' , English : 'Engineering' , subIds : [ '3600' , '3700' , '0500' ,'0600','1900','2100','2200','2300','2400','2500','2600','2700','2900','2800','3000','3200','4100'] } ,
		{ Chinese : '��ѧ' , English : 'Law' , subIds : [ '0900'  ] } ,
		{ Chinese : '��ʷѧ' , English : 'History' , subIds : [ '1300' ] } ,
		{ Chinese : '��ѧ' , English : 'Science' , subIds : [ '1400' , '1500' , '1600' , '3100', '1700', '1800', '0100', '3800', '2000'] } ,
		{ Chinese : '����ѧ' , English : 'Education' , subIds : [ '0800'  ] } ,
		{ Chinese : 'ҽѧ' , English : 'Medicine' , subIds : [ '3400','4000' ] } ,
		{ Chinese : 'ũѧ' , English : 'Agriculture' , subIds : [ '3300' ] }
	];

	pt.getNewMajorLayerSubColNum = function( len ) { return len > 16 ? 2 : 1; }

	pt.initNewMajorLayer = function() {

		//table
		this.createTbl();
		
		//title tr
		this.createTitleTr();

		//selected tr
		if ( this.isMulty ) {
			this.createSelectedTr();
			//seprator line
			var tr = this.tbl.insertRow( -1  );
			var td = document.createElement( 'td' );
			td.colSpan =  this.colNum;
			td.className = 'jlSeprator';
			tr.appendChild( td );
		}
		
		//select trs
		for ( var i = 0 ; i < this.NewMajorLayerPare.length ; i++ ) {
			this.NewMajorLayerPare[i]['pareName'] = this.NewMajorLayerPare[i][this.cfg.fullLang] + '��';
			this.NewMajorLayerPare[i]['pareClassName'] = 'bigOrange';
			if ( 0 == i % 2 ) {
				this.NewMajorLayerPare[i]['trClassName'] = 'bgGray';
			}
			this.createSelectTr( this.NewMajorLayerPare[i] );
		}

		//bottom line
		this.createBottomLine();
	}

})();
