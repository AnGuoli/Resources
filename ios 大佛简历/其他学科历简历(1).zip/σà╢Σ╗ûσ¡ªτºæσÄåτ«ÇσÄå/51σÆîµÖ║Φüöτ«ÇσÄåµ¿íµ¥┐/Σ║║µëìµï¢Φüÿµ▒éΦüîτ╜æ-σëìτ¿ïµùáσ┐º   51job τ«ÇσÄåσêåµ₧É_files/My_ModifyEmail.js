function Modify_Info( action )
{
	if ( !window.pop ) {
		var Modify_Info_Param = {
			openType: 2 , //���ж�λ
			divProps: { style : { zIndex : 1007 } } ,
			filterParam: {} //�˾�������
		}
		window.pop = new ExtZzLayer( Modify_Info_Param );
	}
	
	if(isEnglish == 1)
	{
		var action_url = MYPATH+"/emy/My_Modify_Info.php";
	}
	else
	{
		var action_url = MYPATH+"/my/My_Modify_Info.php";
	}
	
	$.post( action_url, { action: action } , function(result) {
		pop.setContent( result );
		pop.setCloseNode( 'window_close' );
		pop.open();
	} );
}

function EmailResend( email,searchid,searchname,isEnglish )
{
	if ( !window.pop ) {
		var Modify_Info_Param = {
			openType: 2 , //���ж�λ
			filterParam: {} //�˾�������
		}
		window.pop = new ExtZzLayer( Modify_Info_Param );
	}
	
	$.post(MYPATH+"/AjaxAction/my/MyCenter_EmailResend.php", { email: email ,searchid:searchid,searchname:searchname,isEnglish:isEnglish} , function(result) {
	if (result!='({status:nologin})'){
		pop.setContent( result );
		pop.setCloseNode( 'window_close' );
		pop.open();
	}else{
		self.location.href=MYPATH_MY+'/My_SignOut.php'
	}
	} );
}

function Change_Tab( TabName,language )
{
	if ( !window.pop ) {
		var Modify_Info_Param = {
			openType: 2 , //���ж�λ
			filterParam: {} //�˾�������
		}
		window.pop = new ExtZzLayer( Modify_Info_Param );
	}
	
	if(language == 'EN')
	{
		var action_url = MYPATH+"/emy/My_Modify_Info.php";
	}
	else
	{
		var action_url = MYPATH+"/my/My_Modify_Info.php";
	}
	
	$.post( action_url,{ action:TabName },function(result) {
		pop.setContent( result );
		pop.setCloseNode( 'window_close' );
		pop.open();
	} );
}

function Save_Email( language )
{
	var email = $.trim($("#newemail")[0].value).toLowerCase();
	var vldcode = $.trim($("#validatecode")[0].value);
	if(language == 'EN')
	{
		var action_url = MYPATH+"/emy/My_ModifyE.php";
	}
	else
	{
		var action_url = MYPATH+"/my/My_ModifyE.php";
	}
	
	if( email == '' ){
		if(language == 'EN')
		{
			window.alert( "Please enter your email address!" );
		}
		else
		{
			window.alert( "����������E-mail��ַ ��" );
		}
		$("#newemail")[0].focus();
		return false;
	}
	if(vldcode == '')
	{
		if(language == 'EN')
		{
			window.alert( "Please enter verification code!" );
		}
		else
		{
			window.alert( '��������֤�룡' );
		}
		$("#validatecode")[0].focus();
		return false;
	}
	
	if( chkUserEmail( email,language ) )
	{
		//ada insert �����Ż����� 2013-6-27 start @yahoo.com.cn 
		var myreg = /^(([0-9a-zA-Z]+)|([0-9a-zA-Z]+[_.0-9a-zA-Z-]*))@yahoo.(\S)+$/;
	    if(myreg.test(email))
	    {
	    	if(language == 'EN')
			{ 
				  window.alert( "Recommend that you do not use Yahoo Mail, Yahoo Mail service has been stopped��" );
			}
			else
			{ 
				  window.alert( "��������Ҫʹ���Ż����䣬�Ż�������ֹͣ����" );
			}
		      $("#newemail")[0].focus();
			  return false;
		}   
		//ada insert �����Ż����� 2013-6-27 end
		$.post( action_url, { action: "save", newemail: email,vldcode:vldcode } , function(result) {
			pop.setContent( result );
			pop.setCloseNode( 'window_close' );
			pop.setCloseNode( 'window_close_ok' );
			pop.open();
			if( ($("#email_modify_ok")[0]) && ($("#email_modify_ok")[0].value == '1') )
			{
				if($("#email")[0].nodeName.toLowerCase() == 'input')
				{
					$("#email").val(email);
				}
				else
				{
					$("#email").html($("#email_v")[0].value);
				}
				if(document.getElementById('mailcenter_email'))
				{
					$("#mailcenter_email").html(email);
				}
			}
		} );
	}
    return false;
}

function Save_UserName( language )
{
	var oldusername_v = $.trim($("#oldusername")[0].value).toLowerCase();
	var userpwd_v = $.trim($("#userpwd")[0].value);
	var newusername_v =  $.trim($("#newusername")[0].value).toLowerCase();
	var vldcode_v = $.trim($("#validatecode").val());
	
	if( oldusername_v == '' ){
		if(language == 'EN')
		{
			window.alert( "Please enter existing member ID!" );
		}
		else
		{
			window.alert( "�������û�����" );
		}
		$("#oldusername")[0].focus();
		return false;
	}
	if( userpwd_v == '' ){
		if(language == 'EN')
		{
			window.alert( "Please enter password!" );
		}
		else
		{
			window.alert( '���������룡' );
		}
		$("#userpwd")[0].focus();
		return false;
	}
	if(vldcode_v == '')
	{
		if(language == 'EN')
		{
			window.alert( "Please enter verification code!" );
		}
		else
		{
			window.alert( '��������֤�룡' );
		}
		$("#validatecode")[0].focus();
		return false;
	}
	if( chkUserName( newusername_v,language ) )
	{
		if(language == 'EN')
		{
			var action_url = MYPATH+"/emy/My_ModifyU.php";
		}
		else
		{
			var action_url = MYPATH+"/my/My_ModifyU.php";
		}
		$.post( action_url, { action: "save", oldusername: oldusername_v, userpwd: userpwd_v, newusername: newusername_v, vldcode:vldcode_v } , function(result) {
			pop.setContent( result );
			pop.setCloseNode( 'window_close' );
			pop.setCloseNode( 'window_close_ok' );
			pop.open();
			if( ($("#username_modify_ok")[0]) && ($("#username_modify_ok")[0].value == '1') )
			{
				if(document.getElementById('top_username'))
				{
					$("#top_username").attr('title',$("#title_username").val());
					$("#top_username").html($("#show_username").val());
				}
				if(document.getElementById('mailcenter_username'))
				{
					$("#mailcenter_username").html($("#show_username").val());
				}
			}
		} );
	}else{
		$("#newusername")[0].focus();
		return false;
	}
}

function Save_PassWord( language )
{
	var olduserpwd_v = $.trim($("#olduserpwd")[0].value);
	var newuserpwd_v = $.trim($("#newuserpwd")[0].value);
	var newuserpwdcfm_v = $.trim($("#newuserpwdcfm")[0].value);
	var vldcode_v       = $.trim($("#validatecode")[0].value);

	if( olduserpwd_v == '' ){
		if(language == 'EN')
		{
			window.alert( "Please enter existing password!" );
		}
		else
		{
			window.alert( "����������룡" );
		}
		$("#olduserpwd")[0].focus();
		return false;
	}

	var chkResult = chkUpwdIsCorrect();
	var error_msg='';
	switch(chkResult)
	{
		case 1:
			error_msg = language == 'EN' ? 'Please enter your new password.' : '����������';
			break;
		case 2:
			error_msg = language == 'EN' ? 'The new passwords you entered do not match. Please re-enter them.' : '���������벻����Ҫ�����������롣';
			break;
		case 3:
			error_msg = language == 'EN' ? 'The new password can not contain special characters.' : '�������в��ܺ��������ַ�';
			break;
		case 4:
			error_msg = language == 'EN' ? 'New password can not be with the username or email.' : '���������û���/���䲻����ͬ';
			break;
		case 5:
			error_msg = language == 'EN' ? 'The new passwords you entered do not match. Please re-enter them.' : '���������벻����Ҫ�����������롣';
			break;
	}
	if(error_msg != '')
	{
		window.alert( error_msg );
		$("#newuserpwd")[0].focus();
		return false;
	}
	
	if( newuserpwdcfm_v == '' ){
		if(language == 'EN')
		{
			window.alert( "Please confirm your password!" );
		}
		else
		{
			window.alert( "�������ظ������룡" );
		}
		$("#newuserpwdcfm")[0].focus();
		return false;
	}
	if( newuserpwd_v != newuserpwdcfm_v ){
		if(language == 'EN')
		{
			window.alert( "Password confirmation error!" );
		}
		else
		{
			window.alert( "�����ظ���һ�£�" );
		}
		$("#newuserpwd")[0].focus();
		return false;
	}
	if(vldcode_v == '')
	{
		if(language == 'EN')
		{
			window.alert( "Please enter verification code!" );
		}
		else
		{
			window.alert( '��������֤�룡' );
		}
		$("#validatecode")[0].focus();
		return false;
	}


	if(language == 'EN')
	{
		var action_url = MYPATH+"/emy/My_ModifyP.php";
	}
	else
	{
		var action_url = MYPATH+"/my/My_ModifyP.php";
	}
	$.post( action_url, { action: "save", olduserpwd: olduserpwd_v, newuserpwd: newuserpwd_v, newuserpwdcfm: newuserpwdcfm_v,vldcode:vldcode_v } , function(result) {
		pop.setContent( result );
		pop.setCloseNode( 'window_close' );
		pop.setCloseNode( 'window_close_ok' );
		pop.open();
	} );
    return false;
}

//����ǿ�ȼ��� 
function checkStrong(password)
{
	var chkResult = chkUpwdIsCorrect();
	var pwdLevel = '0';
	if( chkResult == 0 ) //chkResult=0˵�����������֣���ĸ������������ٰ���2���ҳ�����6-16
	{
		var re_num    = /[0-9]+/g;	    //��������
		var re_char	  = /[a-zA-Z]+/gi; //������ĸ
		var re_spchar = /[^0-9a-zA-Z]+/gi; //���������ַ�
		if(password.length > 5 && password.length < 11) //6-10 �л��ߵ�
		{
			if(re_num.test(password) && re_char.test(password) && re_spchar.test(password))
			{
				pwdLevel = '2';
			}else
			{
				pwdLevel = '1';
			}
		}else if(password.length > 10 && password.length < 17) //11-16 �л��߸�
		{
			if(re_num.test(password) && re_char.test(password) && re_spchar.test(password))
			{
				pwdLevel = '3';
			}else
			{
				pwdLevel = '2';
			}
		}
	}
	return pwdLevel;
}

function chkUpwdIsCorrect()
{
	var chkResult = 0;
	var str = $.trim($("#newuserpwd")[0].value);
	if(str.length == '')
	{
		chkResult = 1;

	}else if(str.length < 6 || str.length > 16)
	{
		chkResult = 2;
	}else
	{
		//����������Ƿ�����ascii����[0,32],[127-255]֮����ַ�����2��������ַ��Ƿ�
		var i,as_code;
		for(i = 0; i < str.length; i++)
		{
			as_code = str.charCodeAt(i);
			if(as_code < 33 || as_code > 126 )
			{
				chkResult = 3;
				return chkResult;
			}
		}

		//����������û������������Ƿ��ظ�
		var user_email = $.trim($("#my_email").val());
		var user_name  = $.trim($("#my_username").val());
		if(str == user_email.toLowerCase() || str == user_name.toLowerCase())
		{
			chkResult = 4;
		}else //��������Ƿ�һ����
		{
			//��һ���֣���ĸ���������
			var re_num    = /^[0-9]+$/g;
			var re_char	  = /^[a-zA-Z]+$/gi;
			var re_spchar = /^[^0-9a-zA-Z]+$/gi;
			if( re_num.test(str) || re_char.test(str) || re_spchar.test(str))
			{
				chkResult = 5;
			}
		}
	}
	return chkResult;
}

//��ʾ��ɫ 
function pwStrength(pwd)
{
	$("#userpwd_strength").show();
	var O_color="#eeeeee";
	var L_color="#eb0027";
	var M_color="#ffc200";
	var H_color="#11b100";
	
	var Lcolor,Mcolor,Hcolor,O_color;

	$("#strength_L")[0].style.color = "#000000";
	$("#strength_M")[0].style.color = "#000000";
	$("#strength_H")[0].style.color = "#000000";
	
	if (pwd==null||pwd=='')
	{ 
		Lcolor=Mcolor=Hcolor=O_color;
	}
	else
	{
		S_level=checkStrong(pwd);
		switch(S_level) 
		{ 
			case '0': 
				Lcolor=Mcolor=Hcolor=O_color;
				break;
			case '1': 
				Lcolor=L_color;
				Mcolor=Hcolor=O_color;
				$("#strength_L")[0].style.color = "#ffffff"; 
				break; 
			case '2': 
				Lcolor=Mcolor=M_color;
				Hcolor=O_color;
				$("#strength_L")[0].style.color = "#ffffff";
				$("#strength_M")[0].style.color = "#ffffff"; 
				break; 
			case '3': 
				Lcolor=Mcolor=Hcolor=H_color; 
				$("#strength_L")[0].style.color = "#ffffff";
				$("#strength_M")[0].style.color = "#ffffff"; 
				$("#strength_H")[0].style.color = "#ffffff";
				break;
		}
	}
	$("#strength_L")[0].style.background = Lcolor;
	$("#strength_M")[0].style.background = Mcolor;
	$("#strength_H")[0].style.background = Hcolor;
	return; 
}