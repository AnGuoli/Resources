<!--
	 function initial()
        {
        	var a;
        	var i=initial.arguments.length;
		while(i>0)
        	{
        		a=initial.arguments[(i--)-1];
        		if (a.style.display=="none")
        			a.style.display="block";
			else
				a.style.display="none";
		}
	}
	function IsBlock(object1,object2)
	{
		if(object2.style.display=="block")
   		 {
			object1.src="../images/close.gif";
			object2.style.display="none";
    		}
		else
		{
			object1.src="../images/open.gif";
			object2.style.display="block";
	}
}
	
-->

     			