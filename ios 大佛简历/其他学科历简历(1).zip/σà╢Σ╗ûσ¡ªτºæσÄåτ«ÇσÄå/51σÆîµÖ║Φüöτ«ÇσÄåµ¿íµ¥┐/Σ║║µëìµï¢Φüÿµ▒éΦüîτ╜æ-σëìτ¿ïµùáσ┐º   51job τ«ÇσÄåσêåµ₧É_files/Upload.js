function Upload(ReSumeID,isEnglish)
{
	var AttachID=$.trim($("#AttachID")[0].value);
	if ( !window.UploadFile ) {
		var Upload = {
			openType: 2 , //���ж�λ
			filterParam: {} //�˾�������
		}
		window.UploadFile = new ExtZzLayer( Upload );
	}
	$.get(MYPATH+"/AjaxAction/cv/CV_Attach_Photo.php?ran="+Math.random(), { ReSumeID : ReSumeID,AttachID : AttachID,isEnglish: isEnglish } ,  function(result) {
		if (result=='nologin'){
			allowPrompt = false;
			self.location.href=MYPATH_MY+'/My_SignOut.php'
		}else{
		UploadFile.setContent( result );
		UploadFile.setCloseNode( 'Upload_close' );
		UploadFile.open();
	}
} );
}

function Upload_save()
{
	var Filepath=document.Upload_Form.userfile.value;
	Filepath=Filepath.RTrim();
	var pathlength=Filepath.length;
	var cutlength1=pathlength-4;
	var cutlength2=pathlength-5;
	if (  Filepath== "" || (Filepath.substring(1,2)!=':' && Filepath.substring(cutlength1,cutlength1+1)!='.' && Filepath.substring(cutlength2,cutlength2+1)!='.'))
  { 
  	if (isEnglish=='1'){ 
  		window.alert("Please select file.");
	  }else{
	  	window.alert("��ѡ�񸽼���");
	  }
     document.Upload_Form.userfile.focus();
     return false;
  } 
	if (  Filepath== "" || (Filepath.substring(0,1)==' ' || Filepath.substring(cutlength1,cutlength1+1)!='.' && Filepath.substring(cutlength2,cutlength2+1)!='.'))
  { 
  	if (isEnglish=='1'){ 
  		window.alert("Please select file.");
	  }else{
	  	window.alert("��ѡ�񸽼���");
	  }
     document.Upload_Form.userfile.focus();
     return false;
  } 
		var options = {
	        success:       UploadResponse  // post-submit callback
	    }; 
		$("#Upload_Form").ajaxSubmit(options);
}
 
// post-submit callback 
function UploadResponse(responseText, statusText)  {
	if(statusText == 'success')
	{
		if (responseText=='nologin'){
			self.location.href=MYPATH_MY+'/My_SignOut.php'
		}else{
			if ($.trim(responseText)!=''){
				if ($.trim(responseText)=='error_size'){
					$("#error_size").show();
					return false;
				}else if($.trim(responseText)=='error_file'){
					$("#error_file").show();
					return false;
				}else{
				$("#photo").html(responseText);
				$("#photo").show();
				$("#nophoto").hide();
			}
		}else{
			$("#nophoto").show();
			$("#photo").hide();
		}
		UploadFile.close();
    }
  }
}

function delAtttach(ReSumeID)
{
	if (ReSumeID=='')
		return false;

	var AttachID=$.trim($("#AttachID")[0].value);
	var NextAction='del';
	$.get(MYPATH+"/AjaxAction/cv/CV_Attach_Photo.php?ran="+Math.random(), { ReSumeID : ReSumeID,AttachID : AttachID, NextAction : NextAction } ,  function(result) {
		if ($.trim(result)=='nologin'){
			self.location.href=MYPATH_MY+'/My_SignOut.php'
		}
		if ($.trim(result)=='true'){
			$("#nophoto").show();
			$("#photo").hide();
			$("#AttachID")[0].value="";
		}
	} );
}