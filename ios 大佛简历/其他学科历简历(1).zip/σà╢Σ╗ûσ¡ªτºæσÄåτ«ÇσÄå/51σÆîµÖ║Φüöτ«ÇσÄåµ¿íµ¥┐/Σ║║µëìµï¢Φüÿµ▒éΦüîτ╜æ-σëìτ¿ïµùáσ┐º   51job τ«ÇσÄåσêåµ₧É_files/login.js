function fadeShow(idObjSrc,idShowDivContainer,hotArea){
  this.strTimeOut = "";
  this.bleIsShow = false;
  this.idObjSrc = "";
  
  if(typeof(idObjSrc) == "object"){
    this.idObjSrc = idObjSrc;
  } else if(typeof(idObjSrc) == "string"){
    this.idObjSrc = "#" + idObjSrc;
  }
  
  this.hotArea = hotArea || this.idObjSrc;

  this.idShowDivContainer = "";
  if(typeof(idShowDivContainer) == "object"){
    this.idShowDivContainer = idShowDivContainer;
  } else if(typeof(idShowDivContainer) == "string"){
    this.idShowDivContainer = "#" + idShowDivContainer;
  }
  this.init();
}

fadeShow.prototype.init = function(){
  var thisObj =  this;
  var widthTemp = $(this.idShowDivContainer).outerWidth();
  var objTop = $(this.idObjSrc).offset().top;
  var objLeft = $(this.idObjSrc).offset().left;
  var objWidth = $(this.idObjSrc).width();
  var objHeight = $(this.idObjSrc).height();
  var leftTemp = parseInt(objLeft)+parseInt(objWidth)-parseInt(widthTemp);
  var topTemp = parseInt(objTop)+parseInt(objHeight);
  $(this.idShowDivContainer).css({position:"absolute",top:topTemp + "px",left:leftTemp+"px"}).mouseout(function(e){
    thisObj.hide(e);
  });
  $(this.hotArea).mouseout(function(e){
    thisObj.hide(e);
  });
}

fadeShow.prototype.hide = function(evt){
  evt = (evt)?evt:window.event;
  var toElementObj;
  if($.browser.msie){
    toElementObj = evt.toElement;
  } else if($.browser.mozilla){
    toElementObj = evt.relatedTarget;
  } else {
    toElementObj = evt.relatedTarget;
  }
  var thisObj = this;
  if ($(this.idShowDivContainer)[0].contains(toElementObj) || $(this.hotArea)[0].contains(toElementObj)) {
    this.bleIsShow = false;
  } else {
    this.bleIsShow = true;
    if(this.strTimeOut == ""){
      this.strTimeOut = setTimeout(function(){thisObj.doHide()},1000);
    }
  }
}

fadeShow.prototype.doHide = function(){
  if(this.strTimeOut != ""){
    clearInterval(this.strTimeOut);
    this.strTimeOut = "";
  }
  if(!this.bleIsShow){
    return ;
  }
  $(this.idShowDivContainer).fadeOut("slow");
}

fadeShow.prototype.show = function(){
  $(this.idShowDivContainer).fadeIn("slow");
}

var objLoginDiv = "";

var objAreaDiv = "";

function showLoginDiv(obj){
  var widthTemp = $("#loginDiv").outerWidth();
  var objTop = $(obj).offset().top;
  var objLeft = $(obj).offset().left;
  var objWidth = $(obj).width();
  var objHeight = $(obj).height();
  var leftTemp = parseInt(objLeft)+parseInt(objWidth)-parseInt(widthTemp);
  var topTemp = parseInt(objTop)+parseInt(objHeight);
  $("#loginDiv").css({"zIndex":2,position:"absolute",top:topTemp + "px",left:leftTemp+"px"}).show();
  $("#top_login_form_validate_tips").html("&nbsp;");
  $("#top_login_username").val("");
  $("#top_login_userpwd").val("");
  $("#top_login_username")[0].focus();
  $("#top_login_submit_btn")[0].disabled = false;
}
function showLoginWin(type) {	
	LightBox.init();
	LightBox.Show();//����ҳ��Ԫ��
	switch( type ) { 
		case 0:
		default://Ĭ�Ͼ�����ʾ
			var loginDiv= document.getElementById('loginDiv');
			
			var left = Math.round((document.body.clientWidth - loginDiv.offsetWidth) / 2 );
			var top = Math.round((document.body.clientHeight-  loginDiv.offsetHeight) / 2 ) - 200;	
			
			loginDiv.style.zIndex = 2000;
			loginDiv.style.position = "fixed";
			loginDiv.style.display = "block";
			loginDiv.style.left = left + "px";
			loginDiv.style.top = top + "px";
	}	
}


var myDomainMy = "";
function loginInSpeacial(para){
  myDomainMy = para.domain_my;
  myDomainMySSL = para.domain_my_ssl;
  var sucess = para.sucess;
  if(typeof sucess == "function"){
    $("#top_login_form").unbind("submit");
    $("#loginDiv").unbind("");
    $("#top_login_form")[0].onsubmit = "";
    $("#top_login_form").submit(function(){
      return loginIn(myDomainMy,myDomainMySSL,sucess);
    });
  }
}

function showAreaDiv(obj,thisObj){
  if(objAreaDiv == ""){
    objAreaDiv = new fadeShow(obj,"all-channel",thisObj);
  }
  objAreaDiv.show();
}

function loginIn(MYPATH,MYPATHSSL){
  var lang = $("#top_login_language").val();
  if(lang == "en"){
    var str_input_username = "please input user ID";
    var str_input_userpwd = "please input password";
    var str_logining = "logining...";
    var topusername = $("#top_login_username").val();
    if(window.location.href.indexOf("/default-gj-e.php") > 0){
      if(topusername.length > 14){
        topusername = topusername.slice(0,11) + "...";
      }
    } else if(window.location.href.indexOf("/default-xs-e.php") > 0){
      if(topusername.length > 12){
        topusername = topusername.slice(0,9) + "...";
      }
    } else {
      if(topusername.length > 20){
        topusername = topusername.slice(0,16) + "...";
      }
    } 
    var str_hello = "hi," + topusername;
    var str_password_username_error = "wrong user ID or password";
    var str_net_error = "net error!";
  } else {
    var str_input_username = "�������û���";
    var str_input_userpwd = "�������û�����";
    var str_logining = "���ڵ�¼...";
    var topusername = $("#top_login_username").val();
    if(topusername.length > 20){
      topusername = topusername.slice(0,16) + "...";
    }
    var str_hello = topusername+"����ã�";
    var str_password_username_error = "�û������������";
    var str_net_error = "�������!";
  }
  if($.trim($("#top_login_username").val()) == ""){
    $("#top_login_form_validate_tips").html(str_input_username);
    return false;
  }
  if($.trim($("#top_login_userpwd").val()) == ""){
    $("#top_login_form_validate_tips").html(str_input_userpwd);
    return false;
  }
  $("#top_login_form_validate_tips").html(str_logining);
  $("#top_login_submit_btn")[0].disabled = true;
  var sucess = "";
  if(arguments.length > 2){
    sucess = arguments[2];
  }
  var username = $.trim($("#top_login_username").val());
  var password = $.trim($("#top_login_userpwd").val());
  $.ajaxSetup({async:false});
  $.getJSON(MYPATHSSL + '/my/My_ChkLoginInfo.php?' + Math.random() + '&jsoncallback=?', {username:username,password:password}, function (data){});
  $.ajaxSetup({async:true});
  var myUrl = MYPATHSSL + "/my/My_AjaxLogin.php?rand="+new Date().getTime()+"&jsoncallback=?";
  $.getJSON(myUrl,{username:username,userpwd:password,type:"in"},function(data){
    var loginStatus = data.status;
	if(loginStatus == 2){
	  if(lang == "en"){
		hrefUrl = '/emy/My_Pmc.php';
	  }else{
		hrefUrl = '/my/My_Pmc.php';
	  }
	  window.location.href = MYPATH + '/my/My_Validate.php?url=' + encodeURIComponent( hrefUrl );
	} else if(loginStatus == 1){
      if(typeof sucess == "function"){
        sucess();
        objLoginDiv = "";
        $("#top_login_form_validate_tips").html("");
        $("#loginname").html(str_hello.toLowerCase());
        $("#loginInLink").hide();
        $("#loginOutLink").show();
      } else if(sucess != "" && typeof sucess == "string"){
        window.location.href = sucess;
      } else {
        $("#loginname").html(str_hello.toLowerCase());
        $("#loginInLink").hide();
        $("#loginOutLink").show();
        hideLoginDiv();
      }
    }else if(loginStatus == 3)
	{
		window.location.href = MYPATH + '/my/My_Modphone.php';
	}else if(loginStatus == 4)
	{
		window.location.href = MYPATH + '/my/My_Modpwd.php';
	}else if(loginStatus == 0){
      $("#top_login_form_validate_tips").html(str_password_username_error);
    } else {
      $("#top_login_form_validate_tips").html(str_net_error);
    }
    $("#top_login_submit_btn")[0].disabled = false;
  });
  return false;
}

function hideLoginDiv(){
  $("#loginDiv").fadeOut("slow");
    if(LightBox.obj) {
		LightBox.Close();
    }
}

if(typeof(HTMLElement) != "undefined"){
  HTMLElement.prototype.contains = function(obj) {
  while(obj != null &&  typeof(obj.tagName) != "undefind"){
    if(obj == this)
      return true;
      obj = obj.parentNode;
    }
    return false;
  };
}
//��������
function type_search(districtVal){
 obj = document.forms.type_form;
 var districtVal12 = districtVal.substr( 0 , 2 );
 obj.district.value = districtVal;
 obj.jobarea.value = '99' == districtVal12 || '0302' == districtVal ? '0302' : districtVal12+'00';
 obj.submit();
}



var objOtherAreaDiv = "";
var objOtherCityDiv = "";
function onloadFun(){
  if(window.$){
    $(document).ready(function(){
      /*ȥ�����ӣ�button��image button�ĵ��ʱ���߿�*/
      $("a,input[type='button'],input[type='image'],input[type='submit'],area").bind("focus",function(){
        if(this.blur){
          this.blur();
        }
      })
      var obj = document.getElementById("51job|dev|all-channel1");
      if(obj != null){
        $(obj).mouseover(function(){
          if(objOtherAreaDiv == ""){
            objOtherAreaDiv = new fadeShow(this,"all-channel1");
          }
          objOtherAreaDiv.show();
        }).css({cursor:"pointer"});
      }
      
      var obj = document.getElementById("51job|dev|selectcity");
      if(obj != null){
        $(obj).mouseover(function(){
          if(objOtherCityDiv == ""){
            objOtherCityDiv = new fadeShow(this,"selectcity");
          }
          objOtherCityDiv.show();
        }).css({cursor:"pointer"});
      }
    })
  } else {
    setTimeout("onloadFun()",1000);
  }
}
onloadFun();

function imgover(targetid,key){
    if (document.getElementById){
	target=document.getElementById(targetid);
	target.style.display="inline";
		switch(key){
			case 'A':
				target.style.left = '-18px';
				target.style.top = '-26px';
				break;
			case 'B':
				target.style.left = '-16px';
				target.style.top = '-26px';
				break;
			case 'C':
				target.style.left = '-46px';
				target.style.top = '-26px';
				break;
			case 'D':
				target.style.left = '28px';
				target.style.top = '-26px';
				break;
			case 'E':
				target.style.left = '92px';
				target.style.top = '-26px';
				break;	
			case 'F':
				target.style.left = '104px';
				target.style.top = '-26px';
				break;
			case 'G':
				target.style.left = '134px';
				target.style.top = '-26px';
				break;
			case 'H':
				target.style.left = '-37px';
				target.style.top = '-26px';
				break;
			case 'J':
				target.style.left = '30px';
				target.style.top = '-26px';
				break;
			case 'K':
				target.style.left = '238px';
				target.style.top = '-26px';
				break;
			case 'L':
				target.style.left = '-82px';
				target.style.top = '1px';
				break;
			case 'M':
				target.style.left = '13px';
				target.style.top = '1px';
				break;   
			case 'N':
				target.style.left = '-16px';
				target.style.top = '1px';
				break;    	
			case 'Q':
				target.style.left = '22px';
				target.style.top = '1px';
				break;
			case 'S':
				target.style.left = '-22px';
				target.style.top = '1px';
				break;
			case 'T':
				target.style.left = '59px';
				target.style.top = '1px';
				break;
			case 'W':
				target.style.left = '60px';
				target.style.top = '1px';
				break;
			case 'X':
				target.style.left = '119px';
				target.style.top = '1px';
				break;
			case 'Y':
				target.style.left = '90px';
				target.style.top = '1px';
				break;
			case 'Z':
				target.style.left = '-3px';
				target.style.top = '1px';
				break;
		}
    }
}
function imgout(targetid){
    if (document.getElementById){
	target=document.getElementById(targetid);
	target.style.display="none";
    }
}


/*************************����ͨ�ú���****************************************/
var Sys = (function(ua){ 
	var s = {}; 
	s.IE = ua.match(/msie ([\d.]+)/)?true:false; 
	s.Firefox = ua.match(/firefox\/([\d.]+)/)?true:false; 
	s.Chrome = ua.match(/chrome\/([\d.]+)/)?true:false; 
	s.IE6 = (s.IE&& ([ /MSIE (\d)\.0/i.exec(navigator.userAgent)][0][1] == 6))?true:false; 
	s.IE7 = (s.IE&&([/MSIE (\d)\.0/i.exec(navigator.userAgent)][0][1] == 7))?true:false; 
	s.IE8 = (s.IE&&([/MSIE (\d)\.0/i.exec(navigator.userAgent)][0][1] == 8))?true:false; 
	return s; 
})(navigator.userAgent.toLowerCase()); 

/**
 *  IE6����ͼƬĬ�ϲ�����
 */
Sys.IE6 && document.execCommand("BackgroundImageCache", false, true); 

var $_ = function (id) { 
	return  "string" == typeof id ? document.getElementById(id) : id; 
};

/**
 *�������Ԫ��ִ��fun����
 * params Array list  ����
 * params Function fun ����Ԫ����Ҫִ�еĺ��� 
 */ 
function Each(list, fun){ 
	for (var i = 0, len = list.length; i < len; i++) {fun(list[i], i); } 
}; 

//��Ԫ������CSS
var Css = function(e, o){ 
	if(typeof o=="string") 
	{ 
		e.style.cssText = o; 
		return; 
	} 
	for(var i in o) 
		e.style[i] = o[i]; 
}; 
//��Ԫ����������
var Attr = function(e, o){ 
	for(var i in  o) 
		e.setAttribute(i,o[i]); 
}; 

var $$ = function( p, e){ 
	return p.getElementsByTagName(e); 
}; 

/**
 * ����һ��htmlԪ��
 * params String e htmlԪ��
 * params Object p ָ������Ԫ�أ�Ĭ��Ϊdocument
 * params Function fn  �Դ�����Ԫ��ִ��fn����
 * return Object htmlԪ��
 */
function create(e, p, fn){ 
	var element = document.createElement(e); 
	p && p.appendChild(element);
	fn && fn(element);
	return element; 
};
 
function getTarget(e){ 
	e = e||window.event; 
	return e.srcElement||e.target; 
}; 

/**
 * ����һ��tri��,tdi�еı���
 * params int tri ����
 * params int tdi ���� 
 * params Function arisetab �Դ�����tableִ��arisetab����
 * params Function arisetr  ��ÿһ��trִ��arisetr����
 * params Function arisetd  ��ÿһ��tdִ��arisetd����
 * params Object p  	   ����ĸ���Ԫ��
 * return Object ����
 */
function createtab(tri, tdi, arisetab, arisetr, arisetd, p){ 
	var table = p ? p.createElement("table") : create("table"); 
	arisetab && arisetab(table); 
	var tbody = p ? p.createElement("tbody") : create("tbody"); 
	for(var i=0; i<tri; i++) 
	{ 
		var tr = p ? p.createElement("tr") : create("tr"); 
		arisetr && arisetr(i, tr); 
		for(var j=0; j<tdi; j++) 
		{ 
			var td = p ? p.createElement("td") : create("td"); 
			arisetd && arisetd(i, j, td); 
			tr.appendChild(td); 
		} 
		tbody.appendChild(tr); 
	} 
	table.appendChild(tbody); 
	return table; 
}; 

//�̳����Ժͷ���
var Extend = function(destination, source) { 
	for (var property in source) { 
		destination[property] = source[property]; 
	} 
};
 
//�󶨶��󷽷�
var Bind = function(object, fun) { 
	var args = Array.prototype.slice.call(arguments).slice(2); 
	return function() { 
		return fun.apply(object, args); 
	} 
};
 
//�󶨶����¼�
var BindAsEventListener = function(object, fun, args ) { 
	var args = Array.prototype.slice.call(arguments).slice(2); 
	return function(event) { 
		return fun.apply(object, [event || window.event].concat(args)); 
	} 
}; 

//��ȡ�������ʽ
var CurrentStyle = function(element){ 
	return element.currentStyle || document.defaultView.getComputedStyle(element, null); 
}; 

//��ȡ�����λ��
var Getpos = function(o){ 
	var x = 0, y = 0; 
	do{
		x += o.offsetLeft; y += o.offsetTop; 
	}
	while((o = o.offsetParent)); 
	return {'x':x, 'y':y }; 
}; 
/**
 * Ԫ�ظ����¼����¼���������
 * params Object element  ��Ҫ���¼�����������Ԫ��
 * params String e        �¼�
 * params Function fn     �¼���������
 */
function addListener(element, e, fn){ 
	element.addEventListener ? element.addEventListener(e, fn, false) : element.attachEvent("on" + e, fn); 
}; 
/**
 * Ԫ�ظ����¼��Ƴ��¼���������
 * params Object element  ��Ҫ�Ƴ��¼�����������Ԫ��
 * params String e        �¼�
 * params Function fn     �¼���������
 */
function removeListener(element, e, fn){ 
	element.removeEventListener ? element.removeEventListener(e, fn, false) : element.detachEvent("on" + e, fn); 
}; 

//usage:  var Editor = new Class(...);
var Class = function(properties){ 
	var _class = function(){
		return  ( arguments[0] !== null && this.initialize && typeof(this.initialize) == 'function') ? this.initialize.apply(this, arguments) : this;
	}; 
	_class.prototype = properties; 
	return _class; 
}; 

var LightBox = { 
	obj : null, 
	config : { 
		Color : "#fff", 
		Opacity : 30, 
		zIndex : 5 
	}, 
	init : function( options ){ 
		Extend(this.config, options||{}); 
		Extend(this, this.config); 
		delete this.config; 
		
		this.obj = document.body.insertBefore(document.createElement("div"), document.body.childNodes[0]); 
		var str = "display:none; z-index:"+this.zIndex+";left:0px;top:0px;position:fixed;width:100%;height:100%;background-color:"
			+ this.Color + (Sys.IE ? ";filter : alpha(opacity:" + this.Opacity + ")" : ";opacity :"+ this.Opacity / 100); 
		Css(this.obj, str); 
		
		if(Sys.IE6){ 
			this.obj.style.position = "absolute"; 
			var _self = this; 
			this._resize = function(){ 
				_self.obj.style.width = Math.max(document.documentElement.scrollWidth, document.documentElement.clientWidth) + "px"; 
				_self.obj.style.height = Math.max(document.documentElement.scrollHeight, document.documentElement.clientHeight)+"px"; 
			}; 
			this.obj.innerHTML = '<iframe style="position:absolute;top:0;left:0;width:100%;height:100%;filter:alpha(opacity=0);"></iframe>'; 
		} 
		return this; 
	}, 
	Show : function(){ 
		if(Sys.IE6){
			this._resize(); addListener(window,"resize", this._resize); 
		} 
		this.obj.style.display = "block"; 
	}, 
	Close : function(){ 
		this.obj.style.display = "none"; 
		if(Sys.IE6)	
			removeListener(window,"resize", LightBox._resize); 
	} 
};



