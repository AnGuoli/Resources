$("document").ready(
function ()
{
    var url = document.location.href;
    $("#hd2011mainNav2-Box ul li a").each(function ()
    {

        if (url.indexOf($(this).attr("href")) >=0)
        {
            $(this).parent().addClass("hd2011current");
        }
    });


    if (url.indexOf("resume_list.asp") >= 0 || url.indexOf("resume_hits.asp") >= 0 || url.indexOf("job_letter.asp") >= 0)
    {
        $("#resume_li_mng").addClass("hd2011current");
    }
    if ( url.indexOf("jobmng_applied.asp") >= 0 || url.indexOf("jobmng_maillist.asp") >= 0)
    {
        $("#apply_li").addClass("hd2011current");
    }
}
);
//获取职位订阅条件对应的职位数
$(".navBody1").click(function ()
{
    var _top = $(this).offset().top,
        _left = $(this).offset().left;
    $(".nav_listmain").css({ "left": _left - 6 + "px", "top": _top - 1 + "px" }).show()
});
$(".nav_listmain").mouseleave(function ()
{
    $(".nav_listmain").hide();
})
$(".navBody2").click(function ()
{
    var _top = $(this).offset().top,
        _left = $(this).offset().left;
    $(".nav_listmain_1").css({ "left": _left - 6 + "px", "top": _top - 1 + "px" }).show()
});
$(".nav_listmain_1").mouseleave(function ()
{
    $(".nav_listmain_1").hide();
})
$("#passwordChange").click(function ()
{
    $.popupDiv({ title: "修改我的密码", url: "http://my.zhaopin.com/myzhaopin/person_pass.asp", success: function ()
    {

        $("#passwordOld").validate({
            rules: [{
                text: "请输入6－25位密码",
                rule: "password"
            }],
            validText: "",
            tipTagId: "passwordOld_warn"
        });
        $("#password1").validate({
            rules: [{
                text: "请输入6－25位密码",
                rule: "password"
            }],
            validText: "",
            tipTagId: "password1_warn"
        });
        $("#password2").validate({
            rules: [{
                text: "请再次输入6－25位密码",
                rule: "password"
            }, {
                text: "两次输入的密码不一致",
                rule: function (s)
                {
                    if ($("#password1").val() == $("#password2").val())
                    {
                        return true;
                    } else
                    {
                        return false;
                    }
                }
            }],
            validText: "",
            tipTagId: "password2_warn"
        });


    },
        buttons: {
            "保 存": function ()
            {
                $.validate("frmPassword", function ()
                {
                    var param = "oldpassword=" + $("#passwordOld").val() + "&newpassword=" + $("#password1").val() + "&newpasswordrepeate=" + $("#password2").val();
                    $.post("/myzhaopin/person_pass_save.asp", param, function (data)
                    {
                        if (data == "ok")
                        {
                            $.popupDiv({
                                title: "修改我的密码",
                                msg: '<div class="passwordSuccessfully">密码修改成功！</div>',
                                buttons: {
                                    "关 闭": function ()
                                    {
                                        $.popupClose();
                                    }
                                }
                            });
                        }
                        else if(data.length<=100)
                        {
                            alert(data);
                        }
                    }
                     );

                }, function ()
                {
                });
            }
        }, width: 414
    });
    return false;
});


$("#edmSubscribe").click(edmSub);

function edmSub(){
	var flag_lists="",flag_edm_1="",flag_edm_2="",flag_post=false;
    $.popupDiv({title: "邮件服务", url: "http://my.zhaopin.com/myzhaopin/edmSubscribe.asp?t="+Date.parse(new Date()), success: function ()
    {
		if ($("#status_lists").val()=="1"){
			$("#lists_1").attr("checked","checked");
		}
		else{
			$("#lists_0").attr("checked","checked");
		}
		if ($("#status_edm_1").val()=="1"){
			$("#edm_1_1").attr("checked","checked");
		}else{
			$("#edm_1_0").attr("checked","checked");
		}
		if ($("#status_edm_2").val()=="1"){
			$("#edm_2_1").attr("checked","checked");
		}else{
			$("#edm_2_0").attr("checked","checked");
		}
    },
        buttons: {
            "保 存": function ()
            {
               if ($("#status_lists").val()=="1"&&$("#lists_0").attr("checked")=="checked"){
					flag_lists="N";
					flag_post=true;
               }else if ($("#status_lists").val()!="1"&&$("#lists_1").attr("checked")=="checked"){
					flag_lists="Y";
					flag_post=true;
               }
			   if ($("#status_edm_1").val()=="1"&&$("#edm_1_0").attr("checked")=="checked"){
					flag_edm_1=0;
					flag_post=true;
               }else if ($("#status_edm_1").val()!="1"&&$("#edm_1_1").attr("checked")=="checked"){
					flag_edm_1=1;
					flag_post=true;
               }
			   if ($("#status_edm_2").val()=="1"&&$("#edm_2_0").attr("checked")=="checked"){
					flag_edm_2=0;
					flag_post=true;
               }else if ($("#status_edm_2").val()!="1"&&$("#edm_2_1").attr("checked")=="checked"){
					flag_edm_2=1;
					flag_post=true;
               }
			   if (flag_post){
					$.ajax({
						url:"edmSubscribe_save.asp",
						data:{"lists":flag_lists,"edm_1":flag_edm_1,"edm_2":flag_edm_2},
						success:function(res){
							$.popupDiv({
								title:"邮件服务",
								msg:"您的设置保存成功",
								buttons:{"关 闭":function(){$.popupClose();},"返 回":function(){$.popupClose();edmSub();}}
							});
						},
						error:function(){
							$.popupDiv({
								title:"邮件服务",
								msg:"抱歉，保存失败，请稍后重试",
								buttons:{"关 闭":function(){$.popupClose();},"返 回":function(){$.popupClose();edmSub();}}
							});
						}
					});
			   }else{
					$.popupDiv({
						title:"邮件服务",
						msg:"您的设置保存成功",
						buttons:{"关 闭":function(){$.popupClose();},"返 回":function(){$.popupClose();edmSub();}}
					});
			   }

            }
			,"取 消": function(){$.popupClose();}
        }, width: 520
    });
    return false;
};


var email  = new MZ_REG.formEle(true,"email",null,"email_info",['','','请输入新的注册邮箱','E-mail地址长度不能超过100位！','请输入正确的邮箱','该邮箱已被注册','[%%email_regErrShow%%]','检测到您使用雅虎邮箱注册，此邮箱即将停止服务，请更换为其他'],['%%email_regerr%%']);
function checkRegForm(){
	var f = document.regform;
	var flag = regForm.checkForm();
	return flag;
}
function idfn(id){return document.getElementById(id) ;}
/**邮箱验证**/
idfn("email").onfocus = function(){
    this.parentNode.className = "emailaddrr" ;
}
idfn("email").onblur = function(){
	email.fnBlur();
	if(email.checkData(this) == "0"){MZ_REG.checkMailByAJAX(this.form.email);}else{
		this.parentNode.className = "inputTexte" ;
	}
}
/**提交验证**/
idfn("nextstepbtn").onclick = function(){
	if(idfn("email_info").className =="msg_error"){return false;}
	if(checkRegForm()){
		var newEmail = $("#email").val();
		var oldEmail = $("#emailOld").val();
		$.ajax({
                url: "http://my.zhaopin.com/v5/handler/ChangeEmailHandler.ashx",
                dataType: 'jsonp',
                jsonp: 'jsoncallback',
                data: { "usermaster_id": $("#uid").val(), "emailOld": oldEmail, "email": newEmail},
                success: function (json) {
                    switch (json.status) {
                        case "0":
							$("#emailOld").val(newEmail);
							$("#emailshow").val(newEmail);
							$("#email1").val(newEmail);
							$("#oldemail").html(newEmail);
							$("#emailtips a").html(newEmail);
                            $("#newwid2").hide();
							$("#divMask").remove();
							$.popupDiv({title: "邮箱验证", url: "http://my.zhaopin.com/myzhaopin/activeEmail.asp?e="+oldEmail+"&l="+$("#loginNameOld").val()+"&t="+Date.parse(new Date()),width: 414,heigth:300});
                            $("#email").val("").parent().addClass("cenclebtn") ;
                            $("#email_info").text("");
                            break;
						case "3":
							$("#email_info").html("必填项为空！");
                            break;
						case "4":
							$("#email_info").html("email地址未做修改!");
                            break;
                        case "10008":
                        case "10018":
							$("#email_info").html("用户不存在!");
                            break;
                        case "10028":
							$("#email_info").html("email已存在，请重新输入！");
                            break;
                        default:
                            break;
                    }
                },
                error: function () {
                    alert("操作异常，请稍后重试！");
                }
            });
	}
}
/**弹窗方法**/
function newWidfn(id){
	$.popupBase.init({div:$("#"+id),maskClose:false,posx:"center",posy:"center"});
}
/**点击出现修改邮箱的弹窗**/
$("#emailChange").click(function () {
	newWidfn("newwid2");
});
$("#newwid2 .close").click(function(){
        $("#email").val("").parent().addClass("cenclebtn") ;
        $("#email_info").text("");
});

var regForm = new MZ_REG.iniForm('regform');
/**my主页未验证点击**/
$("#emailtips a").click(function () {
	$.popupDiv({title: "邮箱验证", url: "http://my.zhaopin.com/myzhaopin/reSendRegEmail.asp?t="+Date.parse(new Date()),width:480});
});
/**点此重发**/
$("#reSendEmail").live("click",function(){
	$.popupDiv({title: "邮箱验证", url: "http://my.zhaopin.com/myzhaopin/reSendRegEmail.asp?rep=y&t="+Date.parse(new Date())
				,success: function (){
					setTimeout(function(){
						var divPopup = $("#divPopup");
						if (divPopup.length) {
							divPopup.remove();
							if ($("#divMask").length) {
								$("#divMask").hide();
							}
							if ($("#fixedPopupIframe").length) {
								$("#fixedPopupIframe").hide();
							}
						}						
					},5500)
				},width:480
			});
});
